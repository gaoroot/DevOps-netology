# DevOps-netology
change 1   
change 2   
> Цитата 1  
> Цитата 2  
> Тест

```
git diff  
```
```
git commit -v  
```

## terraform .gitignore
1. Локальная дирректория .terraform и все её содержимое  
2. Все файлв tfstate  
3. Файл crash.log  
4. Все фалы с расширением tfvars  
5. Файлы override  
6. Фалы terraformrc и terraform.rc  
