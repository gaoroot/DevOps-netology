# Задание №1

## netology.jsonnet
![alt-текст](https://github.com/gaoroot/DevOps-netology/blob/main/intro/screen/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20%D0%BE%D1%82%202021-10-21%2009-28-13.png "netology.jsonnet")

## netology.md
![alt-текст](https://github.com/gaoroot/DevOps-netology/blob/main/intro/screen/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20%D0%BE%D1%82%202021-10-21%2009-29-17.png "netology.md")


## netology.sh
![alt-текст](https://github.com/gaoroot/DevOps-netology/blob/main/intro/screen/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20%D0%BE%D1%82%202021-10-21%2009-29-53.png "netology.sh")

## netology.tf
![alt-текст](https://github.com/gaoroot/DevOps-netology/blob/main/intro/screen/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20%D0%BE%D1%82%202021-10-21%2009-30-06.png "netology.tf")

## netology.yaml
![alt-текст](https://github.com/gaoroot/DevOps-netology/blob/main/intro/screen/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20%D0%BE%D1%82%202021-10-21%2009-32-07.png "netology.tf")

---
# Задание №2

Разработку разделить на этапы,   
Наладить коммуникацию между менеджерами, тестировщиками, программистами для отлаженного взаимодействия.  

Необходима единая инфраструктура с отказоустойчивым решением, чтобы это решение было оптимальным для всех.  Необходимо развернуть нескольких площадок и обеспечить поддержку.  


Разработчикам перейти на единое решение для написание кода, наладить внутреннее тестирование кода.   Использование единой системы контроля версий.   Создание постоянных бекапов и системы мониторинга всех процессов.   

Создать соглашение о модели взаимодействия менеджеров и программистов...  

Обеспечить поддержку изменений.  

Тестирование автоматизировать, результаты тестирования мониторить и сообщать программистам, тестировщикам.  
