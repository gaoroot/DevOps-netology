#!/usr/bin/env bash

STUDENT_NAME="Alexandr Govorin"

echo "my name in ${STUDENT_NAME}"